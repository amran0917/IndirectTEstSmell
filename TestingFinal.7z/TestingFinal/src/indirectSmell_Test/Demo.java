package indirectSmell_Test;

import javax.swing.*;
import java.awt.event.*;
import java.awt.image.ColorModel;
import java.awt.*;
import java.io.File;


public class Demo extends JPanel
   implements ActionListener {
   JButton go;
  
   TestSmell indr;
   JFileChooser chooser;
   String choosertitle;
   
  public Demo() throws Exception {
	  
//	indr = new TestSmell();
    go = new JButton("Enter");
    go.addActionListener(this);
    
    add(go);
   }

   @Override
  public void actionPerformed(ActionEvent e) {
        
    chooser = new JFileChooser(); 
    chooser.setCurrentDirectory(new java.io.File("."));
    chooser.setDialogTitle(choosertitle);
    chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

    chooser.setAcceptAllFileFilterUsed(false);
  
    if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) { 
        try {

            listFilesForFolder(chooser.getSelectedFile());
        } catch (Exception ex) {
            System.out.println( ex);
        }
      
      }
    else {
      System.out.println("No Selection ");
      }
     }
   
   @Override
  public Dimension getPreferredSize(){
    return new Dimension(500, 500);
    } 
  
  public static void listFilesForFolder(File folder) throws Exception 
  {
	  String str="";
	  String path = "";
          String temp = "";

	    for (final File fileEntry : folder.listFiles())
	    {
	       if (fileEntry.isDirectory())  listFilesForFolder(fileEntry);
	      
	      else 
	      {
	        
	    	  
	    	  if (fileEntry.isFile()) 
	    	  	{
			          temp = fileEntry.getName();
			          if ((temp.substring(temp.lastIndexOf('.') + 1, temp.length()).toLowerCase()).equals("java"))
		        	  path = folder.getAbsolutePath() + "\\" + fileEntry.getName();
                                  
                                  if(path.length()>0){
                                  
                                  
                                  TestSmell indr  = new TestSmell(path);
                                  // str+= indr.start();
                                  indr.start();
                                  }
	    	  	}

	      	}
	    }
	    
	    /*
	    JFrame frame=new JFrame();frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    
	    frame.setBounds(0,0,1200,1000);
	    JTextArea label=new JTextArea();
	    label.setText(str);
	    JScrollPane pane=new JScrollPane(label);
	    pane.setBounds(10,10,1000,1000);
	    pane.setBackground(Color.green);
	    frame.add(pane);
	    frame.setBackground(Color.DARK_GRAY);
	    frame.setVisible(true);*/
	}
  
  
  
  public static void main(String s[]) throws Exception 
  {
	  
	  
	  JFrame frame = new JFrame("");
	  //frame.getColorModel();
	   Demo panel = new Demo();
	  
	    
	    frame.addWindowListener(
	      new WindowAdapter()
	      {
	        public void windowClosing(WindowEvent e)
	        {
	          System.exit(0);
	        }
	     }
	      );
	    
	    
	    frame.getContentPane().add(panel,"Center");
	    frame.getColorModel();
		ColorModel.getRGBdefault();
	    frame.setSize(panel.getPreferredSize());
	    frame.setVisible(true);
	    
    }
}