 package indirectSmell_Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestSmell {
	PrintSmell pr = new  PrintSmell();
	int lineC=0;
     int count=0;
     File file;
     FileReader fr;
     BufferedReader br;
     Map<String,String> localmp;
     Map<String,String> globalMap;
     String testMethodName,fileName;
    boolean isSmell = false;
    String cs;
   public String getSelectMethod(String line)
   {
	   
	    String s =line;
	   if (s == null || s.isEmpty()) {
		      return null;
		    }
	   
	   String[] words = s.split("\\s+");
	   
	   String  store = words[words.length-1];
	    
	    if(store.length()==1) 
	    {
	    
		    String withoutLastWord="";
		    for(int i=0;i<words.length-1;i++) 
		    {
		    	withoutLastWord += " "+words[i];
		    }
		    
		   // System.out.println(withoutLastWord);
		    
		    String[] words3 = withoutLastWord.split("\\s+");
		    String  sss = words3[words3.length-1];
		  //  System.out.println(sss);
		    return sss;
	    
	    }
	    
	    else
	    {
	    	String str = "" ;
	    	char[] ch = store.toCharArray();
	    	for(int i=0;i<store.length();i++)
	    	{
	    			if(store.charAt(i)=='{')
	    			{
	    				ch[i]=' ';
	    				
	    			}
	    			 str = String.valueOf(ch);
	    	}
	    	return str;
	    }
	
	   
   }
    public String charRemoveAt(String str, int p) {  
	    return str.substring(0, p) + str.substring(p + 1);  
	 }
    
    public String getAssertParameter(String assest)
    {
    	String s = "";
    	String patt = "[a-zA-Z1-9]+";
        Pattern pattern = Pattern.compile(patt);
        Matcher mr = pattern.matcher(assest);
        if(mr.find()) s = mr.group();
        if (s.equals("")) s= "@";
        return s;
    	
    }
    
    public TestSmell(String path) throws Exception
    {
    	file = new File(path);
        this.fileName = path;
        if(!file.exists()) 
        {
            System.out.println("file not found");
            System.exit(count);
        }
        fr = new FileReader(file);
        br = new BufferedReader(fr);
    }
  
    public String findTestMethodName(String line)
{
    String s = "([a-zA-Z][a-zA-Z0-9]*(t|T)est)|((t|T)est[a-zA-Z][a-zA-Z0-9]*)";
    String objectName = null;
    Pattern pattern = Pattern.compile(s);
    
    Matcher mr = pattern.matcher(line);
    
    if(mr.find())  objectName = mr.group();

    return objectName;
}
    
    public String getTestMethodName() throws IOException
    {
        String line;
        while((line = br.readLine()) != null)
        {
            count++;
            line = findTestMethodName(line);
            if(line!=null)  return line;
        }
        return null;
    }
  
    
    public void start() throws Exception{
    	
    	
        String line,equation[];
 
        globalMap = new HashMap<String,String>();
        int wrongPosition = 0;
        String s = "[a-zA-Z]([a-zA-Z1-9]|_)* *= *((new +[a-zA-Z1-9]*)|([a-zA-Z]+\\.))";
        while((line = br.readLine()) != null )
        {
            count++;
            boolean smell = false;

           if(!line.contains("@Test") && (!line.contains("@test"))) 
            {
            	Pattern pattern = Pattern.compile(s);
                Matcher mr = pattern.matcher(line);
                if(!mr.find()) continue;
                
             
                line = mr.group();
                
                line = line.replaceAll("=", " ");
                line = line.replaceAll("new", " ");
                equation = line.split(" +");
               //System.out.println(line + "   after ");
                globalMap.put(equation[0], equation[1]);
                //System.out.println();
            	continue;
            }
           

            localmp = new HashMap<String,String>();
            wrongPosition = count;
         //   testMethodName = getTestMethodName();
         
         //   if(testMethodName==null) return ;
            
            testMethodName=getSelectMethod(line);
            
            //Entering the method
            while((line = br.readLine())!=null)
            {
                count++;
                if(line.contains("assert")) break;
                String line2 = line;
                Pattern pattern = Pattern.compile(s);
                Matcher mr = pattern.matcher(line);
                if(!mr.find()) continue;
                
                line = mr.group();
                line = line.replaceAll("=|new", " ");
                line =line.replaceAll("\\.", "");
                line2 = line2.replaceFirst("= *[a-zA-Z]+\\.", " ");
                line2=line2.replaceFirst("= *new", " ");
                //line2=line.replaceFirst("[a-zA-Z]\\.", " ")
                //-----------------------------------------------------
                	if(line2.contains("new ")) { 
                		
                		smell = true;
                		
                		
                	}
                	Iterator hm = localmp.entrySet().iterator();
                	
                	//Check local object lying into the object
                	while(hm.hasNext())
                	{
                		Map.Entry element = (Map.Entry)hm.next();
                		String s3 = ((String)element.getKey());
                		if(line2.contains(" "+s3+" ")) smell = true;
                		else if(line2.contains(" "+s3+".")) smell = true;
                		else if(line2.contains(" "+s3+",")) smell = true;
                		else if(line2.contains(" "+s3+")")) smell = true;
                		else if(line2.contains("("+s3+")")) smell = true;
                		else if(line2.contains("("+s3+",")) smell = true;
                		else if(line2.contains("("+s3+" ")) smell = true;
                		else if(line2.contains("("+s3+".")) smell = true;
                		else if(line2.contains(","+s3+",")) smell = true;
                		else if(line2.contains(","+s3+" ")) smell = true;
                		else if(line2.contains(","+s3+".")) smell = true;
                		else if(line2.contains(","+s3+")")) smell = true;
                		
                			
                            Pattern pa = Pattern.compile("= *"+s3+".");
                            Matcher mr1 = pa.matcher(line2);
                            if(mr1.find()) smell= false;
                            
                            if(smell==true) break;
                		
                		 
                	}
                	
                	//CHeck global object into the object
                	
                	hm = globalMap.entrySet().iterator();
                	while(hm.hasNext())
                	{
                		Map.Entry element = (Map.Entry)hm.next();
                		String s3 = ((String)element.getKey());
                		if(line2.contains(" "+s3+" ")) smell = true;
                		else if(line2.contains(" "+s3+".")) smell = true;
                		else if(line2.contains(" "+s3+",")) smell = true;
                		else if(line2.contains(" "+s3+")")) smell = true;
                		else if(line2.contains("("+s3+")")) smell = true;
                		else if(line2.contains("("+s3+",")) smell = true;
                		else if(line2.contains("("+s3+" ")) smell = true;
                		else if(line2.contains("("+s3+".")) smell = true;
                		else if(line2.contains(","+s3+",")) smell = true;
                		else if(line2.contains(","+s3+" ")) smell = true;
                		else if(line2.contains(","+s3+".")) smell = true;
                		else if(line2.contains(","+s3+")")) smell = true;
                		//else if(line2.contains("="+s3+".")) smell = true;
                		lineC=count;
                			
                            Pattern pa = Pattern.compile("= *"+s3+".");
                            Matcher mr1 = pa.matcher(line2);
                            if(mr1.find()) smell= false;
                		if(smell==true) break;
                		
                	}
                	if(smell==true) break;
                	
                //-----------------------------------------------------
                equation = line.split(" +");
                localmp.put(equation[0], equation[1]);
                
            }
           
            
            if(smell) 
            {
            	//if(line!=null) System.out.println(count+" "+line);
            	if(!isSmell) System.out.println(fileName);
            	
            	
            	System.out.println("Test smell Found\n");
            	
            	System.out.println("at Method line_Number: "+(wrongPosition+1));
            //    System.out.println("Line Cumlasdf "+lineC);
            	//and smell line number= " +count
            	
            	 cs+= "In Method line_Number: "+(wrongPosition+1)+"\n";
            	isSmell = true;
            	
            	pr.hudaiPrint("Test smell Found at Method line_Number: "+(wrongPosition+1));
            }
            
            
        }
        if(!isSmell) 
        {
        	
        		System.out.println("At"+fileName+ "\n no Indirect Smell found..."); 
        			cs+= "At"+fileName+ "\n no Indirect Smell found...";
        			pr.hudaiPrint("At"+fileName+ "\n no Indirect Smell found...");    	
        }
        
       // return cs;
        
        
    }
    
}