package indirectSmell_Test;

import java.awt.BorderLayout;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

public class PrintSmell {
	// String[] columns = {"MethodName", "LineNumberofMethod"};
	
	DefaultTableModel model = new DefaultTableModel(); 
	JTable table = new JTable(model); 
	JFrame f= new JFrame();  
	JTextArea area;
	public PrintSmell()
	{
		area=new JTextArea(); 
		area.setBounds(10,30, 800,400);  
		f.add(area);  
        f.setSize(300,300);  
        f.setLayout(null);  
        f.setVisible(true);  
		// Create a couple of columns 
//		model.addColumn("MethodName");
//		model.addColumn("LineNumberofMethod");
	}
	
	public void printSmellNumber(String testObjectName, int wrongPosition)
	{
		
	//final JFrame frame = new JFrame("JTable Demo");
//		String s = "test"+testObjectName;
//		 
//		 Object[][] data = {
//		            {s,wrongPosition+1}
//		            
//		        };
//		
//		JTable table = new JTable(data, columns);
		
//		DefaultTableModel model = new DefaultTableModel(); 
//		JTable table = new JTable(model); 
//
//		// Create a couple of columns 
//		model.addColumn("Col1"); 
//		model.addColumn("Col2"); 

		// Append a row 
	//	model.addRow(new Object[]{"v1", "v2"});
	
//        JScrollPane scrollPane = new JScrollPane(table);
//        table.setFillsViewportHeight(true);
// 
//        JLabel lblHeading = new JLabel("Stock Quotes");
//        lblHeading.setFont(new Font("Arial",Font.TRUETYPE_FONT,24));
// 
//        frame.getContentPane().setLayout(new BorderLayout());
// 
//        frame.getContentPane().add(lblHeading,BorderLayout.PAGE_START);
//        frame.getContentPane().add(scrollPane,BorderLayout.CENTER);
// 
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setSize(550, 200);
//        frame.setVisible(true);
	}
	
	
	public void hudaiPrint(String s)
	{
		// JFrame f= new JFrame();  
			area.setText(s+"\n");
			f.setVisible(true);  
	}

}


//D:\6th semester\SE-605(Software testing and quality assurance)\Test_testing\Bank-Management-System-Java-master